Function Reset-GLT_Module {
[cmdletBinding()]
    Param ()
    Process {
        $Script:GelfLt_Config = @{}
    }
}
